<div>
    <livewire:product-table />
</div>
