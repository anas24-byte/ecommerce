<div>
    <livewire:bread-crumb :url="$currentUrl"/>
</div>
