<?php

namespace App\Livewire;

use Livewire\Component;

class AllProducts extends Component
{
    public function render()
    {
        return view('livewire.all-products');
    }
}
