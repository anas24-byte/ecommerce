<?php

namespace App\Livewire;

use Livewire\Component;

class ProductSection extends Component
{
    public function render()
    {
        return view('livewire.product-section');
    }
}
